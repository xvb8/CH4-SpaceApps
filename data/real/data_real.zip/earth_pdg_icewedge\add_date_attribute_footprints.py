# 1. Read in all footprint files for high, medium, and low directories
# 2. Add 'Date' attribute as YYYYMMDD pulled from filename
# 3. Save this modified footprint file to new footprint directory 

# note: the subdirectories in the new footprints directory have already been created
# because Delta does not allow files written to /scratch to also 
# create the necessary sudirectories. This was done in the command line:
# 1. `find . -type d > /u/julietcohen/dirs.txt` in original footprints dir
# 2. `xargs mkdir -p < /u/julietcohen/dirs.txt` in new footprints dir

# environment used: /scratch/bbou/julietcohen/venv/iwp_2

import geopandas as gpd
import os
import glob
from pathlib import Path

input_dir = Path('/scratch/bbou/julietcohen/IWP/footprint_files_without_date_20230119')
shp_files_posix = sorted(input_dir.rglob('*.shp'))

print('removing "PosixPath()" part of paths')

# remove prefix "PosixPath()" part from each full path
shp_files = []
for file in shp_files_posix:
    # extract just str filepath
    file_str = str(file)
    shp_files.append(file_str)

number_shp_files = len(shp_files)
new_directory = '/scratch/bbou/julietcohen/IWP/footprint_files_with_date_20230119/'

print(f'starting loop to save {number_shp_files} new footprint files to {new_directory}')

for file in shp_files:
    # save the filepath ONLY starting at high/... or medium/... or low/...
    filepath_to_keep = file[68:] 
    # read in basename that contains date
    filename = os.path.basename(file)
    # parse out date from basename
    YYYYMMDD = filename[5:13]
    print(f'reading file {file}')
    gdf = gpd.read_file(file) 
    # add date as column in gdf
    gdf['Date'] = YYYYMMDD
    # save file to new directory
    new_path = new_directory + filepath_to_keep
    gdf.to_file(new_path)
    print(f'wrote new file {new_path}')

print('Script complete.')
